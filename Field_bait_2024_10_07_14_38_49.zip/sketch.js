let cor;
let posiçãoHorizontal; // x
let posiçãoVertical; // y

function setup() {
  
  createCanvas(400, 400);
  background("white")
  cor = color(random (0,255), random (0, 255), random(0, 255));
  PosiçãoHoriental = 200;
  PosiçãoVertical = 200;
}

function draw() {
  

  circle(PosiçãoHorizontal, PosiçãoVertical, 50);
  
  if(mouseX < PosiçãoHorizontal) 
  PosiçãoHorizontal = PosiçãoHorizontal - 1;
  
  fill(cor)
}